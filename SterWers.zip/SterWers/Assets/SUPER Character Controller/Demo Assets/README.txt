SUPER Character AIO is an open source 1st/3rd person rigidbody based character controller for the Unity Engine designed to fit a wide range of game types with it's fully customizable feature set.
The SUPERCharacterController.cs , Super First Person Controller.prefab, and Super Third Person Controller.prefab files are all free to use in both commercial and non-commercial applications with proper credit.

-= NOTICE! =-
All assets in the 'Demo Assets' folder of this package are *NOT* to be used for commercial purposes with out written permission from the creator (Aedan Graves)
To request permission please contact support@aedangraves.info